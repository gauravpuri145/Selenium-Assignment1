package Assignment1;

public class Numberbreak {
    public static void main(String[] args) {
        int[] arr = new int[]{12,34,66,85,900};
       /* arr[0] = 12;
        arr[1] = 34;
        arr[2] = 66;
        arr[3] = 66;
        arr[4] = 85;
        */
        for(int i = 0; i < arr.length; i++){
            if(arr[i] == 85){
                System.out.println("Number 85 found program ended");
                break;
            }
        }
    }
}
